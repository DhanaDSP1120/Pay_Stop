package com.dhanadsp1120.php4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

import static android.icu.lang.UCharacter.GraphemeClusterBreak.V;

public class MainActivity extends AppCompatActivity {

public static EditText username,password;
   public static String d,m,sp,ttt;

    private Object View;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username=(EditText)findViewById(R.id.edit1);
        password=(EditText)findViewById(R.id.edit2);
        username.setText("");
       password.setText("");


    }
    public void accreate(View v)
    {
        Intent ob =new Intent(this,accreate.class);
        startActivity(ob);
    }


    public void checking(View v)

    {
        String url="https://dhanadsp1120.000webhostapp.com/login.php";
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        StringRequest stringRequest= new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                if(response.trim().equals("success")) {
                    Toast.makeText(getApplicationContext(),"login",Toast.LENGTH_LONG).show();
                    login();




                }
                else
                {
                    Toast.makeText(getApplicationContext(),"login error",Toast.LENGTH_LONG).show();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext()," error:"+error.toString(),Toast.LENGTH_LONG).show();

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params=new HashMap<>();
                params.put("name",username.getText().toString().trim());
                params.put("password",password.getText().toString().trim());
                return params;
            }
        };
        requestQueue.add(stringRequest);
    }


    public void qr(View v)
    {
        Intent ob= new Intent(this,qr.class);
        startActivity(ob);
    }
    public void qrscan(View v)
    {
        Intent ob= new Intent(this,qrscan.class);
        startActivity(ob);
    }
    public void login() {
        String url = "https://dhanadsp1120.000webhostapp.com/accretrive.php";
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                d=response;
                String []str=d.split(",");
                m=str[5];
                go();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), " error:" + error.toString(), Toast.LENGTH_LONG).show();

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("name", username.getText().toString().trim());
                params.put("password", password.getText().toString().trim());
                return params;
            }
        };
        requestQueue.add(stringRequest);

    }
    public void go()
    {
        Intent ob =new Intent(this,bottoms.class);
        startActivity(ob);
    }
}
