package com.dhanadsp1120.php4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class accreate extends AppCompatActivity {

    EditText name,password,email,gender,age,type;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accreate);
        name=(EditText)findViewById(R.id.regname);
        password=(EditText)findViewById(R.id.regpassword);
        email=(EditText)findViewById(R.id.regemail);
        gender=(EditText)findViewById(R.id.reggender);
        age=(EditText)findViewById(R.id.regage);
        type=(EditText)findViewById(R.id.regtype);
    }

    public void signup(View v)
    {


        String url="https://dhanadsp1120.000webhostapp.com/register.php";
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        StringRequest stringRequest= new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if(response.trim().equals("success")) {
                    Toast.makeText(getApplicationContext(),"Register success",Toast.LENGTH_LONG).show();
                    welcome();

                }
                else
                {
                    Toast.makeText(getApplicationContext(),"register failed",Toast.LENGTH_LONG).show();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext()," error:"+error.toString(),Toast.LENGTH_LONG).show();

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params=new HashMap<>();
                params.put("name",name.getText().toString().trim());
                params.put("password",password.getText().toString().trim());
                params.put("email",email.getText().toString().trim());
                params.put("gender",gender.getText().toString().trim());
                params.put("age",age.getText().toString().trim());
                params.put("type",type.getText().toString().trim());
                return params;
            }
        };
        requestQueue.add(stringRequest);
    }
public void welcome()
{
    Intent ob =new Intent(this,MainActivity.class);
    startActivity(ob);
}
}
