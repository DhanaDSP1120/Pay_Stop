package com.dhanadsp1120.php4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class amountadd extends AppCompatActivity {
String uns,unp;
EditText am;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amountadd);
        String[]p=MainActivity.sp.split(",");
        uns=p[0];
        unp=p[1];
        am=(EditText)findViewById(R.id.amountenter);
    }
    public void share(View v)
    {
        String url="https://dhanadsp1120.000webhostapp.com/amountadd.php";
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        StringRequest stringRequest= new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                if(response.trim().equals("success")) {
                    Toast.makeText(getApplicationContext(),"amount send success",Toast.LENGTH_LONG).show();
                    send();




                }
                else
                {
                    Toast.makeText(getApplicationContext(),"amount not send",Toast.LENGTH_LONG).show();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext()," error:"+error.toString(),Toast.LENGTH_LONG).show();

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params=new HashMap<>();
                params.put("name",MainActivity.username.getText().toString().trim());
                params.put("password",MainActivity.password.getText().toString().trim());
                params.put("sendname",uns.trim());
                params.put("sendpassword",unp.trim());
                params.put("amount",am.getText().toString().trim());
                return params;
            }
        };
        requestQueue.add(stringRequest);
    }
    public void send()
    {
        Intent ob=new Intent(this,wallet.class);
        startActivity(ob);
    }

}
