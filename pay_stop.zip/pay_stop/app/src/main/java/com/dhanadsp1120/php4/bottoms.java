package com.dhanadsp1120.php4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.util.HashMap;
import java.util.Map;

public class bottoms extends AppCompatActivity {
private EditText n;
    public static ImageView show;
    Fragment  sf=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bottoms);
        show=(ImageView)findViewById(R.id.qrimage);



        BottomNavigationView obj=findViewById(R.id.bottoms_menu);
        obj.setOnNavigationItemSelectedListener(nv);
        getSupportFragmentManager().beginTransaction().replace(R.id.bottomtop,new buttonhome()).commit();


    }
    public  void qr(View v)
    {
        Intent ob=new Intent(this,qr.class);
        startActivity(ob);
    }
    public void wallet(View v)
    {
        Intent ob=new Intent(this,wallet.class);
        startActivity(ob);

    }
    public void ticket(View v)
    {
        Intent ob=new Intent(this,showticket.class);
        startActivity(ob);

    }
    public  void qrscan(View v)
    {
        Intent ob=new Intent(this,qrscanin.class);
        startActivity(ob);
    }

    public void direction(View v)
    {
        Intent ob= getPackageManager().getLaunchIntentForPackage("com.google.android.apps.maps");
        startActivity(ob);
    }

    private  BottomNavigationView.OnNavigationItemSelectedListener nv= new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {



            switch (item.getItemId())
            {
                case R.id.bthm:  sf=new buttonhome();
                break;
                case R.id.btsc:  sf=new buttonscan();
                    break;
                case R.id.btpr:

                    sf=new buttonprofile();

                    break;

            }
            getSupportFragmentManager().beginTransaction().replace(R.id.bottomtop,sf).commit();
            return true;

        }
    };
}
