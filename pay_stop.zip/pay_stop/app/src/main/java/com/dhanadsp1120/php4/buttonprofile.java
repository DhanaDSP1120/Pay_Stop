package com.dhanadsp1120.php4;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class buttonprofile extends Fragment {

TextView n,p,e,gn,a;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

 View o= inflater.inflate(R.layout.bottom_profile,container,false);
n=(TextView)o.findViewById(R.id.ddd);
        p=(TextView)o.findViewById(R.id.up1);
        e=(TextView)o.findViewById(R.id.ue1);
        gn=(TextView)o.findViewById(R.id.ug1);
        a=(TextView)o.findViewById(R.id.ua1);


        String [] str=MainActivity.d.split(",");
        n.setText(str[0]);
        p.setText(str[1]);
        e.setText(str[2]);
        gn.setText(str[3]);
        a.setText(str[4]);
return o;
    }

}
