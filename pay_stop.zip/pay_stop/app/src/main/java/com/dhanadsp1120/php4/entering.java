package com.dhanadsp1120.php4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class entering extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entering);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent ob =new Intent(entering.this,MainActivity.class);
                startActivity(ob);
                finish();
            }
        },3000);
    }
}
