package com.dhanadsp1120.php4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class exmaple extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exmaple);
    }
    public void home(View v)
    {
        Intent ob= new Intent(this,homein.class);
        startActivity(ob);
    }public void scan(View v)
    {
        Intent ob= new Intent(this,scanin.class);
        startActivity(ob);
    }public void profile(View v)
    {
        Intent ob= new Intent(this,profilein.class);
        startActivity(ob);
    }
}
