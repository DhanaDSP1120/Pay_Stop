package com.dhanadsp1120.php4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class home extends AppCompatActivity {
    int ii;
    EditText e;
public    TextView t;
ImageView s;


String urla="http://192.168.43.192/dsp/dhana.jpg";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_home);
        s=(ImageView)findViewById(R.id.ima);

        e=(EditText)findViewById(R.id.ed);
        t=(TextView) findViewById(R.id.te);
        Picasso.with(this).load(urla).into(s);
        String url="http://192.168.43.192/dsp/apk/json.php";
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        StringRequest stringRequest= new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                String [] str=response.split(",");
                t.setText(str[1]);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params=new HashMap<>();
                params.put("name",MainActivity.username.getText().toString().trim());

                return params;
            }
        };
        requestQueue.add(stringRequest);

    }
    public void dd(View v)
    {
    }

    public void cc(View v)
{
    Intent ob= getPackageManager().getLaunchIntentForPackage("com.google.android.apps.maps");
    startActivity(ob);
}


}
