package com.dhanadsp1120.php4;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class qr extends AppCompatActivity {
    EditText name;
    Button create;
    ImageView show;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr);
        show=(ImageView)findViewById(R.id.qrimage);

        String text1=MainActivity.username.getText().toString().trim();
        String text2=MainActivity.password.getText().toString().trim();
        String text4=MainActivity.m;
        String text3;
        text3=text1;
        text3+=',';
        text3+=text2;
        text3+=',';
        text3+=text4;

        MultiFormatWriter d = new MultiFormatWriter();
        try {
            BitMatrix bd = d.encode(text3, BarcodeFormat.QR_CODE, 800, 1000);
            BarcodeEncoder be = new BarcodeEncoder();
            Bitmap bt = be.createBitmap(bd);
            show.setImageBitmap(bt);
        } catch (WriterException e) {
            e.printStackTrace();
        }
    }


}

