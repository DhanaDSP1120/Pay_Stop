package com.dhanadsp1120.php4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class qrscan extends AppCompatActivity {
public static TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrscan);
        result=(TextView)findViewById(R.id.result);
    }
    public void add(View v)
    {
        



    }

    public void qrscanin(View v)
    {
        Intent ob= new Intent(this,qrscanin.class);
        startActivity(ob);
    }
}
