package com.dhanadsp1120.php4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ticket extends AppCompatActivity {

String t;
EditText f,to,a;
TextView r;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket);



        Date cal =  Calendar.getInstance().getTime();
t=cal.toString();


        f=(EditText)findViewById(R.id.from);
        to=(EditText)findViewById(R.id.to);
        a=(EditText)findViewById(R.id.amount);

    }
    public void submit(View v)
    {
        String url="https://dhanadsp1120.000webhostapp.com/ticket.php";
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        StringRequest stringRequest= new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

              MainActivity.ttt=response;
              ticketget();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext()," error:"+error.toString(),Toast.LENGTH_LONG).show();

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params=new HashMap<>();
                params.put("name",MainActivity.username.getText().toString().trim());
                params.put("password",MainActivity.password.getText().toString().trim());
                params.put("from",f.getText().toString().trim());
                params.put("to",to.getText().toString().trim());
                params.put("time",t.trim());
                params.put("amount",a.getText().toString().trim());
                return params;
            }
        };
        requestQueue.add(stringRequest);
    }
public void ticketget()
{
    Intent ob=new Intent(this,showticket.class) ;
    startActivity(ob);

}
}
