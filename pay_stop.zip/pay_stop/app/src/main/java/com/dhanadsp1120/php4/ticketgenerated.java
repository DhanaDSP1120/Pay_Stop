package com.dhanadsp1120.php4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class ticketgenerated extends AppCompatActivity {
TextView tn,td;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_ticketgenerated);
        tn=(TextView)findViewById(R.id.tn);
        td=(TextView)findViewById(R.id.td);
        String x=showticket.dd;
        String [ ]i=x.split(",");
        tn.setText(i[0]);
        td.setText(i[1]);

    }

}
